package net.dark_roleplay.medieval.one_twelve.objects.events.client;

//TODO Update to 1.13
//@EventBusSubscriber(modid = References.MODID, value = Side.CLIENT)
public class OnConfigChange {
	
//	@SubscribeEvent
//	public void onConfigChanged(ConfigChangedEvent.OnConfigChangedEvent event) {
//		if(event.getModID().equals(References.MODID)){
//			ConfigManager.sync(References.MODID, Config.Type.INSTANCE);
//		}
//	}
}