package net.dark_roleplay.medieval.objects.enums;

public enum TelescopeZoom {
	NONE,
	LOW,
	MEDIUM,
	HIGH;
}
