package net.dark_roleplay.medieval.testing.accessoires;

public class RenderLayerPremium{}/*  implements LayerRenderer<EntityPlayer> {

	@Override
	public boolean shouldCombineTextures() {
		return false;
	}

	@Override
	public void doRenderLayer(EntityPlayer entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
		ModelFox mf = new ModelFox();
		Minecraft.getInstance().getRenderManager().renderEngine.bindTexture(new ResourceLocation(References.MODID, "textures/entitys/fox/fox.png"));
		mf.render(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
	}

}
*/