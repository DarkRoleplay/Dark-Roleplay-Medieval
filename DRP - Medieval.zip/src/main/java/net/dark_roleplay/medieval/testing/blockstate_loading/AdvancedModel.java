package net.dark_roleplay.medieval.testing.blockstate_loading;

public class AdvancedModel{}/*  extends ModelBase{
	
    public List<ModelRenderer> boxList = Lists.<ModelRenderer>newArrayList();


}*/
