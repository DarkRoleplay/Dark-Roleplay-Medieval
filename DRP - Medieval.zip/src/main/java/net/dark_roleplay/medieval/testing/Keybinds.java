package net.dark_roleplay.medieval.testing;

import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;

//@EventBusSubscriber(modid = References.MODID,value = Side.CLIENT)
public class Keybinds {

//	public static KeyBinding debugging = new KeyBinding("keyBinding.debuging2", Keyboard.KEY_N, "Dark Roleplay Core");

//	@SubscribeEvent
	public static void KeyInput(KeyInputEvent event) {
//		if(debugging.isKeyDown()) {
//			System.out.println("Test");
//			Minecraft.getInstance().displayGuiScreen(new GuiBrewing());
//		}
	}

}
