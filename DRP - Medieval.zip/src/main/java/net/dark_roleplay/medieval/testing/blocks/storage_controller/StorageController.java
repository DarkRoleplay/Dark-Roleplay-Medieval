package net.dark_roleplay.medieval.testing.blocks.storage_controller;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class StorageController{}/*  extends Block{

	public StorageController() {
		super(Material.ANVIL);
		this.setRegistryName("work_in_progress_block_0");
		this.setTranslationKey("work_in_progress_block_0");
	}

}
*/