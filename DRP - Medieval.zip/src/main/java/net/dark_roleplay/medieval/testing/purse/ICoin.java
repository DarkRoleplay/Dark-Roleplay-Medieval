package net.dark_roleplay.medieval.testing.purse;

public interface ICoin {

}
