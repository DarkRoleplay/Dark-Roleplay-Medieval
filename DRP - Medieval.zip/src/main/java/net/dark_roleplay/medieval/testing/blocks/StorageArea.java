package net.dark_roleplay.medieval.testing.blocks;

public class StorageArea{}/*  extends DRPBlock{

	public StorageArea(String name, BlockSettings settings) {
		super(name, settings);
	}

}
*/