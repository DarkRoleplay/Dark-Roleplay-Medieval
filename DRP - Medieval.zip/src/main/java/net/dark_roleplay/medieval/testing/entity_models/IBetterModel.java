package net.dark_roleplay.medieval.testing.entity_models;

import net.minecraft.client.renderer.BufferBuilder;

public interface IBetterModel {

	public void render(BufferBuilder buffer);

}
