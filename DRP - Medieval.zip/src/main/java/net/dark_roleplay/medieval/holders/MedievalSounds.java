package net.dark_roleplay.medieval.holders;

import net.minecraft.util.SoundEvent;

//@ObjectHolder(value = References.MODID)
public class MedievalSounds {


	public static final SoundEvent SHIPS_BELL = null;
	public static final SoundEvent WAR_HORN = null;

}
