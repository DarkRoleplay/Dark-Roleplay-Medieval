package net.dark_roleplay.medieval.holders;

import net.dark_roleplay.medieval.DarkRoleplayMedieval;
import net.minecraft.block.Block;
import net.minecraftforge.registries.ObjectHolder;

@ObjectHolder(DarkRoleplayMedieval.MODID)
public class MedievalBlocks {

	/* Decoration */
	public static final Block
		TORCH_HOLDER				= null;
}
