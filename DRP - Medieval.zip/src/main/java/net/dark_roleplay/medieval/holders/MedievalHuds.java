package net.dark_roleplay.medieval.holders;

//@ObjectHolder(References.MODID)
public class MedievalHuds {

//	public static final Hud TIMBERED_CLAY_VIEW = null;

}
