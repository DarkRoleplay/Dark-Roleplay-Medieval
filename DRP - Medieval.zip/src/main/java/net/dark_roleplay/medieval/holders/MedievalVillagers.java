package net.dark_roleplay.medieval.holders;

import net.minecraftforge.fml.common.registry.VillagerRegistry.VillagerCareer;
import net.minecraftforge.fml.common.registry.VillagerRegistry.VillagerProfession;

//@ObjectHolder(value = References.MODID)
public class MedievalVillagers {

	public static final VillagerProfession CARPENTER = null;

	public static VillagerCareer CARPENTER_TIMBERER = null;
}
