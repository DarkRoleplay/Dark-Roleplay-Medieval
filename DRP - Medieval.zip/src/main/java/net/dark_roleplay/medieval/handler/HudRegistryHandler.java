package net.dark_roleplay.medieval.handler;

//@EventBusSubscriber(modid = References.MODID, value = Side.CLIENT)
public class HudRegistryHandler {
//
//	@SubscribeEvent
//	public static final void register(RegistryEvent.Register<Hud> registryEvent) {
//		registryEvent.getRegistry().register(new TimberedClayHud(new ResourceLocation(References.MODID, "timbered_clay_view")));
//	}
}
