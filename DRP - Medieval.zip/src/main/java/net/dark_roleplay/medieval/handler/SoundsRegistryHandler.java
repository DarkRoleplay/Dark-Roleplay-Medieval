package net.dark_roleplay.medieval.handler;

//@EventBusSubscriber(modid = References.MODID)
public class SoundsRegistryHandler {
//
//	@SubscribeEvent
//	public static void register(RegistryEvent.Register<SoundEvent> event){
//		event.getRegistry().register(new SoundEvent(new ResourceLocation(References.MODID, "block_ships_bell")).setRegistryName(new ResourceLocation(References.MODID, "ships_bell")));
//		event.getRegistry().register(new SoundEvent(new ResourceLocation(References.MODID, "war_horn_0")).setRegistryName(new ResourceLocation(References.MODID, "war_horn")));
//	}
}
