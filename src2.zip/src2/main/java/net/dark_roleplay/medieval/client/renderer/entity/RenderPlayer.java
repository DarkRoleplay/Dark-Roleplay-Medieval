package net.dark_roleplay.medieval.client.renderer.entity;

public class RenderPlayer {
	
}

