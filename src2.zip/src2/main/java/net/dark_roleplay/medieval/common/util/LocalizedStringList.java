package net.dark_roleplay.medieval.common.util;


public class LocalizedStringList {

	public static String modName = "drpm.util.modName";
	
	
	public static String updateNewVersionAvailable = "drpm.update.newVersionAvailable";
	public static String updateCurrentVersion = "drpm.update.currentVersion";
	public static String updateLatestVersion = "drpm.update.latestVersion";
	public static String updateOpenDownload = "drpm.update.openDownload";
	public static String updateOpenChangelog = "drpm.update.openChangelog";
}
