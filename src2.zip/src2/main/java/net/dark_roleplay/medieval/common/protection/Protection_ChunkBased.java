package net.dark_roleplay.medieval.common.protection;

import java.util.ArrayList;
import java.util.UUID;

import net.minecraft.util.math.ChunkPos;

public class Protection_ChunkBased {

	private ChunkPos chunk;
	
	private int protectionID;
	
	private ArrayList<UUID> owners;
	private ArrayList<UUID> members;
	
	

	
}
