package net.dark_roleplay.medieval.common.blocks.templates;


public enum PlaceSide {
	
	TOP,
	BOTTOM,
	NORTH,
	EAST,
	SOUTH,
	WEST;
}
