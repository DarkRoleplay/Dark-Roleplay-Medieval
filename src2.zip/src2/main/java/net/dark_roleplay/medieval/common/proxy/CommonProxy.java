package net.dark_roleplay.medieval.common.proxy;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class CommonProxy {

	public void init(FMLPreInitializationEvent event) {}
	
	public void init(FMLInitializationEvent event) {}

	public void init(FMLPostInitializationEvent event) {}
	
	public void addItemToRegisterMesh(Item item){}
}
