package net.dark_roleplay.medieval.common.items.misc;

import net.dark_roleplay.medieval.common.handler.DRPMedievalCreativeTabs;
import net.minecraft.item.Item;

public class LeatherBookCoverThik extends Item {

	public LeatherBookCoverThik() {
		this.setRegistryName("LeatherBookCoverThik");
		this.setUnlocalizedName("LeatherBookCoverThik");
		this.setCreativeTab(DRPMedievalCreativeTabs.drpmedievalMiscTab);
	}
	
}
