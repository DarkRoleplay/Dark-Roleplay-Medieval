package net.dark_roleplay.medieval.common.blocks.tileentitys;

import net.minecraft.tileentity.TileEntity;

public class TileEntityShipsWheel extends TileEntity {

}
