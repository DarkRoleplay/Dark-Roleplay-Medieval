package net.dark_roleplay.medieval.common.items.misc;

import net.dark_roleplay.medieval.common.handler.DRPMedievalCreativeTabs;
import net.minecraft.item.Item;

public class LeatherBookCoverThin extends Item {

	public LeatherBookCoverThin() {
		this.setRegistryName("LeatherBookCoverThin");
		this.setUnlocalizedName("LeatherBookCoverThin");
		this.setCreativeTab(DRPMedievalCreativeTabs.drpmedievalMiscTab);
	}
	
}
