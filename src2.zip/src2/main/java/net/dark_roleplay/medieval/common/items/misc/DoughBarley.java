package net.dark_roleplay.medieval.common.items.misc;

import net.dark_roleplay.medieval.common.handler.DRPMedievalCreativeTabs;
import net.minecraft.item.Item;

public class DoughBarley extends Item {

	public DoughBarley() {
		this.setRegistryName("DoughBarley");
		this.setUnlocalizedName("DoughBarley");
		this.setCreativeTab(DRPMedievalCreativeTabs.drpmedievalMiscTab);
	}
}
