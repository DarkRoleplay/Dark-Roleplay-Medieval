package net.dark_roleplay.medieval.common.items.misc;

import net.dark_roleplay.medieval.common.handler.DRPMedievalCreativeTabs;
import net.minecraft.item.Item;

public class FlourWheat extends Item {

	public FlourWheat() {
		this.setRegistryName("FlourWheat");
		this.setUnlocalizedName("FlourWheat");
		this.setCreativeTab(DRPMedievalCreativeTabs.drpmedievalMiscTab);
	}

}
