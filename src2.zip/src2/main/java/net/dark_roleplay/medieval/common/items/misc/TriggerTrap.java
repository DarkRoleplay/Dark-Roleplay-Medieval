package net.dark_roleplay.medieval.common.items.misc;

import net.dark_roleplay.medieval.common.handler.DRPMedievalCreativeTabs;
import net.minecraft.item.Item;

public class TriggerTrap extends Item {

	public TriggerTrap() {
		this.setRegistryName("TriggerTrap");
		this.setUnlocalizedName("TriggerTrap");
		this.setCreativeTab(DRPMedievalCreativeTabs.drpmedievalMiscTab);
	}
}
