package net.dark_roleplay.medieval.common.items.seeds;

public class SeedBarley{// extends AdvancedCropSeed {

//	public SeedBarley() {
//		super(DRPMedievalBlocks.BARLEY, Blocks.FARMLAND);
//		this.setRegistryName("SeedBarley");
//		this.setUnlocalizedName("SeedBarley");
//		this.setCreativeTab(DRPMedievalCreativeTabs.drpmedievalMiscTab);
//	}
}
