package net.dark_roleplay.medieval.common.blocks.decorative.ropeFence;

import java.util.List;

import javax.annotation.Nullable;

import net.dark_roleplay.medieval.common.handler.DRPMedievalCreativeTabs;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class RopeFence extends Block{
	
	public static final PropertyInteger NORTH = PropertyInteger.create("north", 0, 3);
	public static final PropertyInteger EAST = PropertyInteger.create("east", 0, 3);
	public static final PropertyInteger SOUTH = PropertyInteger.create("south", 0, 3);
	public static final PropertyInteger WEST = PropertyInteger.create("west", 0, 3);
	
	public static final PropertyBool NORTH_EAST = PropertyBool.create("north_east");
	public static final PropertyBool SOUTH_EAST = PropertyBool.create("south_east");
	public static final PropertyBool SOUTH_WEST = PropertyBool.create("south_west");
	public static final PropertyBool NORTH_WEST = PropertyBool.create("north_west");
	
    protected static final AxisAlignedBB[] BOUNDING_BOXES = new AxisAlignedBB[] {new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 1.0D, 0.625D), new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 1.0D, 1.0D), new AxisAlignedBB(0.0D, 0.0D, 0.375D, 0.625D, 1.0D, 0.625D), new AxisAlignedBB(0.0D, 0.0D, 0.375D, 0.625D, 1.0D, 1.0D), new AxisAlignedBB(0.375D, 0.0D, 0.0D, 0.625D, 1.0D, 0.625D), new AxisAlignedBB(0.375D, 0.0D, 0.0D, 0.625D, 1.0D, 1.0D), new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.625D, 1.0D, 0.625D), new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.625D, 1.0D, 1.0D), new AxisAlignedBB(0.375D, 0.0D, 0.375D, 1.0D, 1.0D, 0.625D), new AxisAlignedBB(0.375D, 0.0D, 0.375D, 1.0D, 1.0D, 1.0D), new AxisAlignedBB(0.0D, 0.0D, 0.375D, 1.0D, 1.0D, 0.625D), new AxisAlignedBB(0.0D, 0.0D, 0.375D, 1.0D, 1.0D, 1.0D), new AxisAlignedBB(0.375D, 0.0D, 0.0D, 1.0D, 1.0D, 0.625D), new AxisAlignedBB(0.375D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D), new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.625D), new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D)};
	public static final AxisAlignedBB PILLAR_AABB = new AxisAlignedBB(0.375D, 0.0D, 0.375D, 0.625D, 1.5D, 0.625D);
    public static final AxisAlignedBB SOUTH_AABB = new AxisAlignedBB(0.375D, 0.0D, 0.625D, 0.625D, 1.5D, 1.0D);
    public static final AxisAlignedBB WEST_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.375D, 0.375D, 1.5D, 0.625D);
    public static final AxisAlignedBB NORTH_AABB = new AxisAlignedBB(0.375D, 0.0D, 0.0D, 0.625D, 1.5D, 0.375D);
    public static final AxisAlignedBB EAST_AABB = new AxisAlignedBB(0.625D, 0.0D, 0.375D, 1.0D, 1.5D, 0.625D);
	
    //E = X S = Z
    public static final AxisAlignedBB SE_AABB = new AxisAlignedBB(0.625D, 0.0D, 0.625D, 1.0D, 1.5D, 1.0D);
    
    public static final AxisAlignedBB SW_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.625D, 0.375D, 1.5D, 1.0D);
    
    public static final AxisAlignedBB NE_AABB = new AxisAlignedBB(0.625D, 0.0D, 0.0D, 1.0D, 1.5D, 0.375D);
    
    public static final AxisAlignedBB NW_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.375D, 1.5D, 0.375D);
    
	public RopeFence(String registryName) {
		super(Material.WOOD);
		this.setRegistryName(registryName);
		this.setUnlocalizedName(registryName);
		this.setCreativeTab(DRPMedievalCreativeTabs.DECORATION);
		this.setHardness(2F);
		this.setSoundType(SoundType.WOOD);
	}

	@Override
	public IBlockState getStateFromMeta(int meta) {
		return this.getDefaultState();
	}

	@Override
	public int getMetaFromState(IBlockState state) {
		return 0;
	}
	
	@Override
	protected BlockStateContainer createBlockState() {
		return new BlockStateContainer(this, new IProperty[] {RopeFence.NORTH,RopeFence.NORTH_EAST,RopeFence.EAST,RopeFence.SOUTH_EAST,RopeFence.SOUTH,RopeFence.SOUTH_WEST,RopeFence.WEST,RopeFence.NORTH_WEST});
	}
	
	@Override
	public IBlockState getActualState(IBlockState state, IBlockAccess world, BlockPos pos) {
		
		int n = 3;
		int e = 3;
		int s = 3;
		int w = 3;
		boolean ne = false;
		boolean se = false;
		boolean sw = false;
		boolean nw = false;

		if((world.getBlockState(pos.north()).getBlock() == this)){
			n = 1;
		} else if((world.getBlockState(pos.north().up()).getBlock() == this) && world.isAirBlock(pos.up())){
			n = 2;
		} else if((world.getBlockState(pos.north().down()).getBlock() == this)){
			n = 0;
		}else if(world.isSideSolid(pos.north(), EnumFacing.SOUTH, false)){
			n = 1;
		}
		
		if((world.getBlockState(pos.east()).getBlock() == this)) {
			e = 1;
		} else if((world.getBlockState(pos.east().up()).getBlock() == this) && world.isAirBlock(pos.up())){
			e = 2;
		} else if((world.getBlockState(pos.east().down()).getBlock() == this)){
			e = 0;
		}else if(world.isSideSolid(pos.east(), EnumFacing.WEST, false)){
			e = 1;
		}
		
		if((world.getBlockState(pos.south()).getBlock() == this)) {
			s = 1;
		} else if((world.getBlockState(pos.south().up()).getBlock() == this) && world.isAirBlock(pos.up())){
			s = 2;
		} else if((world.getBlockState(pos.south().down()).getBlock() == this)){
			s = 0;
		}else if(world.isSideSolid(pos.south(), EnumFacing.NORTH, false)){
			s = 1;
		}
		
		if((world.getBlockState(pos.west()).getBlock() == this)) {
			w = 1;
		} else if((world.getBlockState(pos.west().up()).getBlock() == this) && world.isAirBlock(pos.up())){
			w = 2;
		} else if((world.getBlockState(pos.west().down()).getBlock() == this)){
			w = 0;
		}else if(world.isSideSolid(pos.west(), EnumFacing.EAST, false)){
			w = 1;
		}
		
		if(((n == 3) && (e == 3)) && (world.getBlockState(pos.north().east()).getBlock() == this)) {
			ne = true;
		}
		
		if(((s == 3) && (e ==3)) && (world.getBlockState(pos.south().east()).getBlock() == this)) {
			se = true;
		}
		
		if(((s == 3) && (w == 3)) && (world.getBlockState(pos.south().west()).getBlock() == this)) {
			sw = true;
		}
		
		if(((n == 3) && (w == 3)) && (world.getBlockState(pos.north().west()).getBlock() == this)) {
			nw = true;
		}

		return state.withProperty(RopeFence.NORTH, n).withProperty(RopeFence.NORTH_EAST, ne).withProperty(RopeFence.EAST, e).withProperty(RopeFence.SOUTH_EAST, se).withProperty(RopeFence.SOUTH, s).withProperty(RopeFence.SOUTH_WEST, sw).withProperty(RopeFence.WEST, w).withProperty(RopeFence.NORTH_WEST, nw);
	}
	
	
	@Override
	public boolean isFullCube(IBlockState state) {
		return false;
	}
	
	@Override
	public boolean isOpaqueCube(IBlockState state) {
		return false;
	}
	
	@Override
	public boolean isPassable(IBlockAccess worldIn, BlockPos pos){
        return false;
    }
	
	@Override
	public void addCollisionBoxToList(IBlockState state, World worldIn, BlockPos pos, AxisAlignedBB entityBox, List<AxisAlignedBB> collidingBoxes, @Nullable Entity entity, boolean p_185477_7_){
		if(entity instanceof EntityPlayer){
			state = state.getActualState(worldIn, pos);
	        Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.PILLAR_AABB.contract(0D, 0.5D, 0D));

	        if (state.getValue(RopeFence.NORTH) != 3) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.NORTH_AABB.contract(0D, 0.5D, 0D));
			}

	        if (state.getValue(RopeFence.EAST) != 3) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.EAST_AABB.contract(0D, 0.5D, 0D));
			}

	        if (state.getValue(RopeFence.SOUTH) != 3) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.SOUTH_AABB.contract(0D, 0.5D, 0D));
			}

	        if (state.getValue(RopeFence.WEST) != 3) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.WEST_AABB.contract(0D, 0.5D, 0D));
			}
	        
	        if (state.getValue(RopeFence.NORTH_EAST).booleanValue()) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.NE_AABB.contract(0D, 0.5D, 0D));
			}

	        if (state.getValue(RopeFence.NORTH_WEST).booleanValue()) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.NW_AABB.contract(0D, 0.5D, 0D));
			}

	        if (state.getValue(RopeFence.SOUTH_EAST).booleanValue()) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.SE_AABB.contract(0D, 0.5D, 0D));
			}

	        if (state.getValue(RopeFence.SOUTH_WEST).booleanValue()) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.SW_AABB.contract(0D, 0.5D, 0D));
			}
		}else{
			state = state.getActualState(worldIn, pos);
	        Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.PILLAR_AABB);

	        if (state.getValue(RopeFence.NORTH) != 3) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.NORTH_AABB);
			}

	        if (state.getValue(RopeFence.EAST) != 3) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.EAST_AABB);
			}

	        if (state.getValue(RopeFence.SOUTH) != 3) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.SOUTH_AABB);
			}

	        if (state.getValue(RopeFence.WEST) != 3) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.WEST_AABB);
			}
	        
	        if (state.getValue(RopeFence.NORTH_EAST).booleanValue()) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.NE_AABB);
			}

	        if (state.getValue(RopeFence.NORTH_WEST).booleanValue()) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.NW_AABB);
			}

	        if (state.getValue(RopeFence.SOUTH_EAST).booleanValue()) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.SE_AABB);
			}

	        if (state.getValue(RopeFence.SOUTH_WEST).booleanValue()) {
				Block.addCollisionBoxToList(pos, entityBox, collidingBoxes, RopeFence.SW_AABB);
			}
		}
    }

	@Override
	public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess source, BlockPos pos)
    {
        state = this.getActualState(state, source, pos);
        return RopeFence.BOUNDING_BOXES[RopeFence.getBoundingBoxIdx(state)];
    }

    private static int getBoundingBoxIdx(IBlockState state){
        int i = 0;

        if (state.getValue(RopeFence.NORTH) != 3)
        {
            i |= 1 << EnumFacing.NORTH.getHorizontalIndex();
        }

        if (state.getValue(RopeFence.EAST) != 3)
        {
            i |= 1 << EnumFacing.EAST.getHorizontalIndex();
        }

        if (state.getValue(RopeFence.SOUTH) != 3)
        {
            i |= 1 << EnumFacing.SOUTH.getHorizontalIndex();
        }

        if (state.getValue(RopeFence.WEST) != 3)
        {
            i |= 1 << EnumFacing.WEST.getHorizontalIndex();
        }

        return i;
    }
}
